"""
Shared DirectRLEnv base class.

Provides: config loading, YAML deep-merge, common initialization
(scene, asset, actuators, contacts), shared step infrastructure,
and config validation (reject null to-be-calibrated values before training).
"""

from __future__ import annotations
import yaml
from pathlib import Path
from typing import Any

from tvc_env.envs.task_registry import deep_merge


class BaseEnvConfig:
    """Container for merged environment configuration."""

    def __init__(
        self,
        task_name: str,
        env_config_path: str | Path | None = None,
        physics_config_path: str | Path | None = None,
        disturbance_config_path: str | Path | None = None,
        overrides: dict | None = None,
        sim_root: str | Path | None = None,
    ):
        from tvc_env.envs.task_registry import load_merged_config
        import yaml

        if sim_root is None:
            sim_root = Path(__file__).parents[2]

        # Load env config if provided
        env_config = None
        if env_config_path is not None:
            with open(env_config_path, "r", encoding="utf-8") as f:
                env_config = yaml.safe_load(f)

        physics_config = None
        automatic_physics_defaults = physics_config_path is None
        if physics_config_path is None:
            physics_config_path = self._default_physics_config_path(sim_root, env_config, overrides)
        if physics_config_path is not None:
            with open(physics_config_path, "r", encoding="utf-8") as f:
                physics_config = yaml.safe_load(f)
            if automatic_physics_defaults and env_config and 'physics' in env_config:
                # Defaults must not silently undo the experiment's explicit
                # solver contract (e.g. coupled midpoint requires one impulse).
                physics_config = deep_merge(physics_config, {'physics': env_config['physics']})

        # Load disturbance config if provided
        disturbance_config = None
        if disturbance_config_path is not None:
            with open(disturbance_config_path, "r", encoding="utf-8") as f:
                disturbance_config = yaml.safe_load(f)

        self.config = load_merged_config(
            task_name=task_name,
            env_config=env_config,
            physics_config=physics_config,
            disturbance_config=disturbance_config,
            overrides=overrides,
            sim_root=sim_root,
        )

        # Extract common settings
        env = self.config.get("env", {})
        self.num_envs: int = env.get("num_envs", 1)
        self.env_spacing: float = env.get("env_spacing", 4.0)
        self.gizmos_enabled: bool = env.get("gizmos_enabled", False)
        self.dispatch_mode: str = env.get("dispatch_mode", "per_link_force")
        self.auto_reset: bool = bool(env.get("reset_on_crash", True))
        physics = self.config.get("physics", {})
        # The env clock is the task-facing source of truth (notably HIL uses
        # 500 Hz); the selected PhysX file supplies a fallback and solver knobs.
        self.physics_dt: float = env.get("physics_dt", physics.get("dt", 1.0 / 120.0))
        self.decimation: int = env.get("decimation", 4)
        self.task_name: str = task_name
        gyro_mode = self.config.get('dynamics', {}).get('gyro_integration', 'rotor_midpoint')
        if gyro_mode not in ('rotor_midpoint', 'coupled_midpoint', 'coupled_cayley'):
            raise ValueError(f'Unknown gyro integration mode: {gyro_mode}')
        if gyro_mode in ('coupled_midpoint','coupled_cayley') and physics.get('enable_external_forces_every_iteration', True):
            raise ValueError('Coupled angular integration requires physics.enable_external_forces_every_iteration: false')
        if self.config.get('task',{}).get('navigation',{}).get('enabled') and not env.get('observe_battery'):
            raise ValueError('Waypoint policy observation contract requires observe_battery: true')

    @staticmethod
    def _default_physics_config_path(
        sim_root: str | Path,
        env_config: dict | None,
        overrides: dict | None = None,
    ) -> Path:
        """Select the default PhysX config from env size/replication settings."""
        env = (env_config or {}).get("env", {}).copy()
        env.update((overrides or {}).get("env", {}))
        num_envs = int(env.get("num_envs", 1))
        replicate = bool(env.get("replicate_physics", num_envs > 1))
        filename = "physx_train.yaml" if num_envs > 1 or replicate else "physx_single.yaml"
        return Path(sim_root) / "configs" / "physics" / filename

    def validate_for_training(self) -> None:
        """Validate config is safe for RL training (no null to-be-calibrated values).

        Raises:
            ValueError: If any null to-be-calibrated parameter is found.
        """
        # Check EDF params
        edf_config_path = Path(__file__).parents[2] / "configs/params/edf_90mm.yaml"
        if edf_config_path.exists():
            with open(edf_config_path, "r", encoding="utf-8") as f:
                edf_cfg = yaml.safe_load(f).get("edf", {})
            # These nulls have defined model semantics: k_T/k_Q are derived
            # when omitted and d_omega_max=None disables the optional slew cap.
            allowed_nulls = {"k_T", "k_Q", "d_omega_max"}
            null_fields = [k for k, v in edf_cfg.items() if v is None and k not in allowed_nulls]
            if null_fields:
                raise ValueError(
                    f"Cannot start training: EDF config has null to-be-calibrated values: "
                    f"{null_fields}. Run bench calibration first and update edf_90mm.yaml."
                )


class TVCEnvBase:
    """Base class with common initialization logic for the TVC environment.

    Concrete environments should subclass this and the Isaac Lab DirectRLEnv.
    """

    def __init__(self, config: BaseEnvConfig):
        self._config = config
        self._step_count = None
        self._reset_manager = None
        self._contact_sm = None
        self._crash_detector = None

    def _initialize_physics_systems(
        self,
        scene,
        articulation,
        metadata: dict[str, Any],
        vehicle_config: dict[str, Any],
        edf_config: dict[str, Any],
        servo_config: dict[str, Any],
        device,
    ) -> None:
        """Initialize all physics subsystems after scene is built."""
        from tvc_env.asset.articulation_map import build_articulation_map
        from tvc_env.dynamics.fin_geometry import load_cop_positions, load_hinge_axes
        from tvc_env.dynamics.fin_aero import FinAeroModel
        from tvc_env.dynamics.fin_force_dispatch import FinForceDispatch
        from tvc_env.dynamics.actuator_servo import ServoModel
        from tvc_env.dynamics.propulsion_edf import EDFModel
        from tvc_env.dynamics.wind_model import WindModel
        from tvc_env.dynamics.com_model import COMOffsetModel
        from tvc_env.sim.body_interface import BodyInterface
        from tvc_env.sim.link_force_interface import LinkForceInterface
        from tvc_env.sim.sensor_interface import SensorInterface
        from tvc_env.sim.wrench_dispatch import WrenchDispatch
        from tvc_env.sim.contacts import ContactStateMachine
        from tvc_env.sim.crash_logic import CrashDetector
        from tvc_env.sim.reset_logic import ResetManager

        num_envs = self._config.num_envs

        # Build articulation map
        art_map = build_articulation_map(metadata, articulation)

        # Geometry
        cops = load_cop_positions(metadata, device=device)
        hinge_axes = load_hinge_axes(metadata, device=device)

        # Physics models
        aero_model = FinAeroModel.from_config(vehicle_config, edf_config)
        servo_model = ServoModel(
            tau_servo=servo_config.get("servo", servo_config).get("tau_servo", 0.05),
            max_angular_velocity=servo_config.get("servo", servo_config).get("max_angular_velocity", 7.54),
            max_command_angle=servo_config.get("servo", servo_config).get("max_command_angle", 0.262),
            deadband=servo_config.get("servo", servo_config).get("deadband", 0.017),
        )
        edf_params = edf_config.get("edf", edf_config)
        edf_model = EDFModel(
            max_thrust=edf_params.get("max_thrust", 48.0),
            tau_motor=edf_params.get("tau_motor", 0.15),
            omega_max=edf_params.get("omega_max") or 3000.0,
            d_omega_max=edf_params.get("d_omega_max"),
            k_T=edf_params.get("k_T"),
            k_Q=edf_params.get("k_Q"),
            rotor_inertia=edf_params.get("rotor_inertia", 0.0005),
            dynamic_torque_scale=edf_params.get("dynamic_torque_scale", 1.0),
            gyro_torque_scale=edf_params.get("gyro_torque_scale", 1.0),
        )

        # Wind model (only if disturbance config enables it)
        dist_cfg = self._config.config.get("disturbances", {})
        if dist_cfg.get("enabled") and dist_cfg.get("wind", {}).get("enabled"):
            wind_model = WindModel.from_disturbance_config(
                self._config.config, num_envs=num_envs, device=device,
            )
        else:
            # Still air is not a vacuum. Vehicle-relative airflow produces
            # translational drag even when external wind disturbances are off.
            body_config = vehicle_config.get("body", {})
            wind_model = WindModel(
                cd=body_config.get("cd_body", 1.0),
                reference_area=body_config.get("reference_area", 0.011),
                num_envs=num_envs, device=device,
            )

        if dist_cfg.get("enabled") and dist_cfg.get("com_offset", {}).get("enabled"):
            com_offset_model = COMOffsetModel.from_disturbance_config(
                self._config.config, device=device,
            )
        else:
            com_offset_model = None

        # Sim interfaces
        body_iface = BodyInterface(articulation, art_map)
        link_force_iface = LinkForceInterface(articulation, art_map, cops)
        link_force_iface.get_fin_cop_positions_world(
            body_iface.get_root_quaternion_wxyz(), body_iface.get_root_position()
        )
        contact_sensor = scene["contact_sensor"]
        sensor_iface = SensorInterface(contact_sensor, metadata)
        wrench_dispatch = WrenchDispatch(
            mode=self._config.dispatch_mode,
            link_force_interface=link_force_iface,
            body_link_index=art_map.body_index,
        )

        # Contact state machine
        contact_sm = ContactStateMachine.from_task_config(
            self._config.config,
            num_envs=num_envs,
            device=device,
        )
        crash_detector = CrashDetector.from_task_config(self._config.config)

        # Reset manager
        battery_model = None
        battery_config = self._config.config.get('battery', {})
        if battery_config.get('enabled', False):
            from tvc_env.dynamics.battery_lipo import LiPoBattery
            battery_model = LiPoBattery(battery_config, num_envs, device)
        env_origins = scene.scene.env_origins if hasattr(scene, "scene") else None
        reset_mgr = ResetManager(
            body_iface,
            servo_model,
            edf_model,
            contact_sm,
            self._config.config,
            env_origins=env_origins,
            com_offset_model=com_offset_model,
            wind_model=wind_model,
            battery_model=battery_model,
        )
        reset_mgr.initialize(num_envs, device)

        # Store as instance attributes
        self._art_map = art_map
        self._body_iface = body_iface
        self._link_force_iface = link_force_iface
        self._contact_sensor = contact_sensor
        self._sensor_iface = sensor_iface
        self._wrench_dispatch = wrench_dispatch
        self._wind_model = wind_model
        self._aero_model = aero_model
        self._body_angular_damping = float(
            vehicle_config.get("body", {}).get("angular_damping", 0.0)
        )
        self._max_fin_thrust_loss_fraction = float(
            vehicle_config.get("fins", {}).get("max_thrust_loss_fraction", 0.3)
        )
        self._fin_dispatch = FinForceDispatch.from_metadata_and_config(
            metadata,
            vehicle_config,
            edf_config,
            device=device,
        )
        self._servo_model = servo_model
        self._edf_model = edf_model
        # Read actual PhysX body inertia, not a damping/tuning surrogate.
        # This asset's COM/principal axes align with its link axes. Convert
        # the tensor from Isaac body axes to FRD (D*I*D).
        locked_inertia=articulation.root_physx_view.get_inertias()[:,art_map.body_index].reshape(-1,3,3).to(device)
        axes=locked_inertia.new_tensor([1.,-1.,-1.])
        self._locked_body_inertia=locked_inertia*axes[None,:,None]*axes[None,None,:]
        self._coupled_jet = None
        jet_config = self._config.config.get('dynamics', {}).get('coupled_jet', {})
        if jet_config.get('enabled', False):
            from tvc_env.dynamics.coupled_jet import CoupledJet
            self._coupled_jet = CoupledJet(jet_config, aero_model, self._fin_dispatch.normal_dirs)
        self._body_geometry = vehicle_config.get('body', {})
        self._battery_model = battery_model
        self._contact_sm = contact_sm
        self._crash_detector = crash_detector
        self._reset_manager = reset_mgr
        self._cops = cops
        self._hinge_axes = hinge_axes
