"""
Articulation state read/write interface for the EDF drone.

Reads root_state_w (position, quaternion wxyz, linear/angular velocity),
reads/writes joint positions and velocities, and provides body-frame velocity
computation using the frames.py conversion boundary.

All quaternions are in (w,x,y,z) convention per Isaac Lab 2.3.2.
Velocities in body-FRD frame are computed via frames.py (single boundary).
"""

from __future__ import annotations
import torch
from torch import Tensor

from tvc_env.common.frames import frd_position_to_isaac, isaac_velocity_to_frd
from tvc_env.common.quaternions import rotate_vector, inverse as quat_inv, normalize


class BodyInterface:
    """Interface for reading and writing articulation body state."""

    def __init__(self, articulation, art_map):
        """
        Args:
            articulation: Isaac Lab Articulation object.
            art_map: ArticulationMap with body/joint index mappings.
        """
        self._art = articulation
        self._map = art_map
        # PhysX exposes COM properties on CPU. Keep the authored values so
        # per-episode COM randomization is absolute rather than cumulative.
        self._default_coms = articulation.root_physx_view.get_coms().clone()

    # ---- Root state reading ----

    def get_root_position(self) -> Tensor:
        """Get root body position in Isaac world frame.

        Returns:
            Tensor of shape (num_envs, 3) in Isaac world frame (m).
        """
        return self._art.data.root_pos_w.clone()

    def get_root_quaternion_wxyz(self) -> Tensor:
        """Get root body orientation as (w,x,y,z) quaternion.

        Returns:
            Tensor of shape (num_envs, 4) in (w,x,y,z) ordering.
        """
        return self._art.data.root_quat_w.clone()

    def get_root_linear_velocity_world(self) -> Tensor:
        """Get root linear velocity in Isaac world frame.

        Returns:
            Tensor of shape (num_envs, 3) in Isaac world frame (m/s).
        """
        return self._art.data.root_lin_vel_w.clone()

    def get_root_angular_velocity_world(self) -> Tensor:
        """Get root angular velocity in Isaac world frame.

        Returns:
            Tensor of shape (num_envs, 3) in Isaac world frame (rad/s).
        """
        return self._art.data.root_ang_vel_w.clone()

    def get_linear_velocity_body_frd(
        self,
        velocity_world: Tensor | None = None,
        quaternion_wxyz: Tensor | None = None,
    ) -> Tensor:
        """Get root linear velocity in body-FRD frame.

        Converts from Isaac world frame using frames.py (single conversion boundary).

        Returns:
            Tensor of shape (num_envs, 3) in body-FRD frame (m/s).
        """
        vel_world = self.get_root_linear_velocity_world() if velocity_world is None else velocity_world
        q_wxyz = self.get_root_quaternion_wxyz() if quaternion_wxyz is None else quaternion_wxyz
        # Rotate world velocity into body frame: v_body = R^T * v_world
        q_inv = quat_inv(normalize(q_wxyz))
        vel_body_isaac = rotate_vector(q_inv, vel_world)
        # Convert from Isaac body convention to FRD
        return isaac_velocity_to_frd(vel_body_isaac)

    def get_angular_velocity_body_frd(
        self,
        angular_velocity_world: Tensor | None = None,
        quaternion_wxyz: Tensor | None = None,
    ) -> Tensor:
        """Get root angular velocity in body-FRD frame.

        Returns:
            Tensor of shape (num_envs, 3) in body-FRD frame (rad/s).
        """
        ang_vel_world = (
            self.get_root_angular_velocity_world()
            if angular_velocity_world is None
            else angular_velocity_world
        )
        q_wxyz = self.get_root_quaternion_wxyz() if quaternion_wxyz is None else quaternion_wxyz
        q_inv = quat_inv(normalize(q_wxyz))
        ang_vel_body_isaac = rotate_vector(q_inv, ang_vel_world)
        return isaac_velocity_to_frd(ang_vel_body_isaac)

    # ---- Joint state reading ----

    def get_joint_positions(self) -> Tensor:
        """Get all joint positions.

        Returns:
            Tensor of shape (num_envs, num_joints) in radians.
        """
        return self._art.data.joint_pos.clone()

    def get_fin_joint_positions(self) -> Tensor:
        """Get fin joint positions in +X, +Y, -X, -Y order.

        Returns:
            Tensor of shape (num_envs, 4) in radians.
        """
        joint_indices = self._map.fin_joint_indices
        return self._art.data.joint_pos[:, joint_indices].clone()

    def get_fin_joint_velocities(self) -> Tensor:
        """Get fin joint angular velocities.

        Returns:
            Tensor of shape (num_envs, 4) in rad/s.
        """
        joint_indices = self._map.fin_joint_indices
        return self._art.data.joint_vel[:, joint_indices].clone()

    # ---- Joint state writing ----

    def set_fin_joint_targets(self, positions: Tensor, env_ids: Tensor | None = None) -> None:
        """Set fin joint position targets (for position-controlled joints).

        Args:
            positions: Tensor of shape (num_envs, 4) in radians.
        """
        joint_indices = torch.tensor(self._map.fin_joint_indices, device=positions.device)
        self._art.set_joint_position_target(positions, joint_ids=joint_indices, env_ids=env_ids)

    def write_fin_joint_state(
        self,
        positions: Tensor,
        velocities: Tensor,
        env_ids: Tensor | None = None,
    ) -> None:
        """Write measured fin joint state during an episode reset.

        Setting only a position target leaves the previous episode's joint
        position and velocity in PhysX. Isaac Lab's articulation reset contract
        requires writing both joint state tensors before clearing buffers.
        """
        joint_indices = torch.tensor(self._map.fin_joint_indices, device=positions.device)
        self._art.write_joint_state_to_sim(
            positions,
            velocities,
            joint_ids=joint_indices,
            env_ids=env_ids,
        )

    def set_body_com_offset_frd(self, offsets_frd: Tensor, env_ids: Tensor) -> None:
        """Apply absolute per-environment root-body COM offsets in body-FRD."""
        env_ids_cpu = env_ids.to(device="cpu", dtype=torch.int64)
        coms = self._default_coms.clone()
        body_id = self._map.body_index
        offsets_isaac = frd_position_to_isaac(offsets_frd).to(device="cpu", dtype=coms.dtype)
        coms[env_ids_cpu, body_id, :3] += offsets_isaac
        self._art.root_physx_view.set_coms(coms, env_ids_cpu)
        # The direct PhysX property setter does not invalidate Isaac Lab 2.3.2
        # lazy COM/derived velocity caches. Refresh them before forces in the
        # same reset step; otherwise r x F uses the previous episode's COM.
        for name in ('_body_com_pose_b','_body_com_pose_w','_root_com_pose_w',
                     '_body_link_vel_w','_root_link_vel_w','_body_state_w',
                     '_body_link_state_w','_body_com_state_w','_root_state_w',
                     '_root_link_state_w','_root_com_state_w'):
            getattr(self._art.data, name).timestamp = -1.0

    def reset_buffers(self, env_ids: Tensor | None = None) -> None:
        """Reset articulation actuator caches and external-wrench state."""
        self._art.reset(env_ids)

    def set_root_state(
        self,
        position: Tensor,
        quaternion_wxyz: Tensor,
        linear_vel: Tensor,
        angular_vel: Tensor,
        env_ids: Tensor | None = None,
    ) -> None:
        """Set root body state for episode reset.

        Args:
            position: Tensor (num_envs, 3) in Isaac world frame (m).
            quaternion_wxyz: Tensor (num_envs, 4) in (w,x,y,z).
            linear_vel: Tensor (num_envs, 3) in Isaac world frame (m/s).
            angular_vel: Tensor (num_envs, 3) in Isaac world frame (rad/s).
            env_ids: Optional environment IDs matching the leading state dimension.
        """
        root_state = torch.cat([position, quaternion_wxyz, linear_vel, angular_vel], dim=-1)
        self._art.write_root_state_to_sim(root_state, env_ids=env_ids)

    def get_altitude(self, ground_level: float = 0.0) -> Tensor:
        """Compute altitude above ground from Isaac world frame z-coordinate.

        In Isaac's Z-up frame, altitude = root_pos_z - ground_level.

        Returns:
            Tensor of shape (num_envs,) in meters.
        """
        pos_z = self._art.data.root_pos_w[:, 2]  # z-up in Isaac
        return pos_z - ground_level
