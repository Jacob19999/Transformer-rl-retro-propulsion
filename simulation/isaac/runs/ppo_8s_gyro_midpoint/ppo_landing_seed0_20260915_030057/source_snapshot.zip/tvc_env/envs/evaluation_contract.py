"""Reject silent plant changes when evaluating a saved PPO controller."""
from copy import deepcopy
import hashlib


def physical_contract(config):
    result = {key: deepcopy(config.get(key, {})) for key in ('edf','servo','dynamics','battery')}
    # SOC is an explicitly identified sensitivity option, not a new pack.
    result['battery'].pop('initial_soc', None)
    result['env'] = {key: config.get('env', {}).get(key) for key in ('physics_dt','decimation','observe_battery','dispatch_mode')}
    result['physics'] = {key: config.get('physics', {}).get(key) for key in (
        'enable_gyroscopic_forces','max_angular_velocity_deg_s','contact_offset','rest_offset',
        'num_position_iterations','num_velocity_iterations','solver_type')}
    result['contact'] = deepcopy(config.get('task', {}).get('contact', {}))
    return result


def plant_mismatches(saved, config, root):
    reasons = []
    if physical_contract(saved.get('task_config', {})) != physical_contract(config):
        reasons.append('resolved physical configuration')
    manifest = saved.get('source_manifest', {})
    paths = [*root.glob('tvc_env/dynamics/*.py'), *root.glob('tvc_env/sim/*.py'),
             root/'tvc_env/envs/base_env.py', root/'tvc_env/envs/direct_rl_env.py',
             *root.glob('configs/vehicle/*.yaml'), root/'configs/params/edf_90mm.yaml',
             root/'configs/params/servo_mg996r.yaml']
    for path in paths:
        key = str(path.relative_to(root))
        # Windows manifests use native separators. JSON records preserve them.
        if manifest.get(key) != hashlib.sha256(path.read_bytes()).hexdigest():
            reasons.append(key)
    return reasons
